# M2

This project was generated with [Angular CLI](https://angular.io/cli) version 12.2.0. To run the project please follow
the Angular CLI instructions to install Angular CLI. After installing the Angular CLI global NPM package,
run `npm install` in the project directory to install the needed packages for this project.

## Running

Run `ng serve` to launch a project server. Navigate to `http://localhost:4200/` in a web browser. The app will automatically reload
if you change any of the source files.

## Further help

To get more help on the Angular CLI use `ng help` or go check out
the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
